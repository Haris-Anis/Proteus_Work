# Sample Proteus Projects

The **Proteus Design Suite** is a proprietary software tool suite used primarily for electronic design automation. The software is used mainly by electronic design engineers and technicians to create schematics and electronic prints for manufacturing printed circuit boards.<br/>
This repository basically contains some sample Proteus design examples which I created at my time of learning.
